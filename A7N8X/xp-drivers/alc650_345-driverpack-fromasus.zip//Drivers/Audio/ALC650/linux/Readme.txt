
The source code copy from www.alsa-project.org.       ver:a1.70
Linux Source Code for ALC audio codec

Installation:
This Source Code is from www.alsa-project.org.
For driver installation, please follow below steps. 

Step 1. You must have full configured source for the Linux kernel.

Step 2. Uncompress the source code
        a. tar xfvj alcsound.tar.bz2
	or	b. unbzip2 alcsound.tar.bz2
			tar -xvf alcsound.tar

Step 3. Turn on sound support (soundcore module)

Step 4. Complied source code
	a. ./Configure
	b. make install
	c. ./snddevices

Step 5. Edit your /etc/modules.conf or conf.modules depending on the Distribution
 	(Please refer to the attached modules.conf)

Step 6. reboot your machine

Note: 	1. The most detail information, can refer the INSTALL file in the alcsound.tar.bz2.
	2. Kernel Version must be 2.2.14 or later.
	3. All mixer channels are muted by default. You must use a native
		or OSS mixer program to unmute appropriate channels.
	4. If can not compile the source code, try to rename the /usr/src/linux-2.x -> /usr/src/linux.
	5. The driver added to support the SPDIF functoin. 	
